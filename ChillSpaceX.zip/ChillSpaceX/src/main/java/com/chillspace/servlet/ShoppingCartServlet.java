package com.chillspace.servlet;

import com.chillspace.dao.ProductDAO;
import com.chillspace.model.Product;
import com.chillspace.model.ShoppingCart;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

public class ShoppingCartServlet extends HttpServlet {

    // Handle GET request to display the shopping cart
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the session cart, create one if it doesn't exist
        HttpSession session = request.getSession();
        ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
        if (cart == null) {
            cart = new ShoppingCart();
            session.setAttribute("cart", cart);
        }

        // Set the cart attribute to the request for JSP rendering
        request.setAttribute("cart", cart);

        // Forward to the shopping cart JSP page
        RequestDispatcher dispatcher = request.getRequestDispatcher("/shopping-cart.jsp");
        dispatcher.forward(request, response);
    }

    // Handle POST request for adding or removing products
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the session cart
        HttpSession session = request.getSession();
        ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
        if (cart == null) {
            cart = new ShoppingCart();
            session.setAttribute("cart", cart);
        }

        // Handle add to cart
        String action = request.getParameter("action");
        int productId = Integer.parseInt(request.getParameter("productId"));
        ProductDAO productDAO = new ProductDAO();
        Product product = productDAO.getProductById(productId);

        if ("add".equals(action)) {
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            cart.addProduct(product, quantity);
        } else if ("remove".equals(action)) {
            cart.removeProduct(productId);
        }

        // Redirect back to the shopping cart page
        response.sendRedirect("shoppingCart");
    }
}

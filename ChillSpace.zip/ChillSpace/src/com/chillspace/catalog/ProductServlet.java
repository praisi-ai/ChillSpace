package com.chillspace.catalog;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/product")
public class ProductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        String action = request.getParameter("action");
        String name = request.getParameter("name");
        String price = request.getParameter("price");

        if (name == null || name.trim().isEmpty() || price == null || !price.matches("\\d+")) {
            request.setAttribute("error", "Invalid name or price");
            request.getRequestDispatcher("/admin/products.jsp").forward(request, response);
            return;
        }

        switch (action) {
            case "add":
                // Add to DB or in-memory list (example only)
                break;
            case "edit":
                break;
            case "delete":
                break;
        }

        response.sendRedirect(request.getContextPath() + "/admin/products.jsp");
    }
}

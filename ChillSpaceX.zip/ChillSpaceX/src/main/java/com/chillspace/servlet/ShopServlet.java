package com.chillspace.servlet;

import com.chillspace.dao.ProductDAO;
import com.chillspace.model.Product;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

public class ShopServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the category parameter from the request
        String category = request.getParameter("category");

        // Fetch products from the database
        ProductDAO productDAO = new ProductDAO();
        List<Product> products;
        
        if (category != null && !category.isEmpty()) {
            // If category is provided, filter products by category
            products = productDAO.getProductsByCategory(category);
        } else {
            // If no category is provided, fetch all products
            products = productDAO.getAllProducts();
        }

        // Set the products as an attribute to pass to the JSP
        request.setAttribute("products", products);

        // Forward the request to the shop.jsp
        RequestDispatcher dispatcher = request.getRequestDispatcher("/shop.jsp");
        dispatcher.forward(request, response);
    }

    // Optional: Handle POST requests if needed (e.g., for form submissions)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}

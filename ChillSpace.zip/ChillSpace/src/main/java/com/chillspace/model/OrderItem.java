package com.chillspace.model;

public class OrderItem {
    
}

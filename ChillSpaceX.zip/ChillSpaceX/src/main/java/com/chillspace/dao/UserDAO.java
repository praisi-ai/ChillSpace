package com.chillspace.dao;

import com.chillspace.model.User;
import com.chillspace.util.DBUtil;
import org.mindrot.jbcrypt.BCrypt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.regex.Pattern;

public class UserDAO {

    // Logger for debugging and tracking errors
    private static final Logger logger = LoggerFactory.getLogger(UserDAO.class);

    // Method to authenticate user during login
    public User loginUser(String email, String password) {
        User user = null;

        // Basic email validation regex
        if (!isValidEmail(email)) {
            logger.error("Invalid email format: {}", email);
            return null; // Invalid email format
        }

        logger.info("Attempting login for user with email: {}", email);

        String query = "SELECT * FROM users WHERE email = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, email);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String storedPasswordHash = rs.getString("password_hash");

                    // Check if passwords match using BCrypt
                    if (BCrypt.checkpw(password, storedPasswordHash)) {
                        user = new User();
                        user.setUserId(rs.getInt("user_id"));
                        user.setUsername(rs.getString("username"));
                        user.setEmail(rs.getString("email"));
                        user.setPasswordHash(storedPasswordHash);
                        user.setRole(rs.getString("role"));
                        logger.info("User {} successfully logged in.", email); // Successful login
                    } else {
                        // Password doesn't match
                        logger.warn("Password mismatch for user: {}", email);
                    }
                } else {
                    logger.warn("No user found with email: {}", email); // No user found
                }
            }

        } catch (SQLException e) {
            logger.error("SQL Exception while executing login query", e); // Log the error if a SQL exception occurs
        }

        return user;
    }

    // Email format validation
    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        Pattern pattern = Pattern.compile(emailRegex);
        return pattern.matcher(email).matches();
    }

    // Method to register a new user
    public boolean registerUser(User user, String password) {
        // Check if the email is already registered
        if (isEmailAlreadyRegistered(user.getEmail())) {
            logger.warn("Email {} is already registered.", user.getEmail());
            return false;  // Email is already registered, return false
        }

        String query = "INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)";

        // Hash the password before storing it
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getEmail());
            pstmt.setString(3, hashedPassword);
            pstmt.setString(4, user.getRole());

            int result = pstmt.executeUpdate();

            if (result > 0) {
                logger.info("User {} successfully registered.", user.getUsername());
                return true;  // Registration successful
            } else {
                logger.warn("User registration failed for: {}", user.getUsername());
            }

        } catch (SQLException e) {
            logger.error("Error during user registration", e); // Log any errors during registration
        }

        return false;  // Return false if registration fails
    }

    // Method to check if the email is already registered
    private boolean isEmailAlreadyRegistered(String email) {
        String query = "SELECT * FROM users WHERE email = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();  // Returns true if the email is found in the database

        } catch (SQLException e) {
            logger.error("Error checking email uniqueness", e);
        }
        return false;  // Return false if email is not found
    }
}

package com.chillspace.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

public class ProductFilterServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String category = request.getParameter("category");
        String minPriceStr = request.getParameter("minPrice");
        String maxPriceStr = request.getParameter("maxPrice");

        List<Map<String, String>> filteredProducts = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/chillspace", "root", "");

            StringBuilder query = new StringBuilder("SELECT * FROM products WHERE 1=1");

            // Add filters dynamically
            if (category != null && !category.isEmpty()) {
                query.append(" AND category = ?");
            }
            if (minPriceStr != null && !minPriceStr.isEmpty()) {
                query.append(" AND price >= ?");
            }
            if (maxPriceStr != null && !maxPriceStr.isEmpty()) {
                query.append(" AND price <= ?");
            }

            PreparedStatement ps = conn.prepareStatement(query.toString());

            int paramIndex = 1;
            if (category != null && !category.isEmpty()) {
                ps.setString(paramIndex++, category);
            }
            if (minPriceStr != null && !minPriceStr.isEmpty()) {
                ps.setDouble(paramIndex++, Double.parseDouble(minPriceStr));
            }
            if (maxPriceStr != null && !maxPriceStr.isEmpty()) {
                ps.setDouble(paramIndex++, Double.parseDouble(maxPriceStr));
            }

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, String> product = new HashMap<>();
                product.put("id", rs.getString("id"));
                product.put("name", rs.getString("name"));
                product.put("price", rs.getString("price"));
                product.put("category", rs.getString("category"));
                filteredProducts.add(product);
            }

            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("products", filteredProducts);
        RequestDispatcher dispatcher = request.getRequestDispatcher("product_list.jsp");
        dispatcher.forward(request, response);
    }
}

package com.chillspace.servlet;

import com.chillspace.dao.CheckoutDAO;
import com.chillspace.model.Order;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.math.BigDecimal;

public class CheckoutServlet extends HttpServlet {

    // Process the checkout form submission
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the form data
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String country = request.getParameter("country");
        String address = request.getParameter("address");
        String city = request.getParameter("city");
        String postalCode = request.getParameter("postalCode");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String orderNotes = request.getParameter("orderNotes");

        // Create an Order object to store the checkout details
        Order order = new Order();
        order.setUserId(1); // Set a hardcoded user ID for now, assuming the user is logged in
        order.setTotalAmount(new BigDecimal("750.99")); // Use the actual total amount (hardcoded here for demo)
        order.setStatus("Pending");
        order.setPaymentStatus("Unpaid");

        // Simulating an order save (this can be done using DAO)
        CheckoutDAO checkoutDAO = new CheckoutDAO();
        boolean isOrderSaved = checkoutDAO.saveOrder(order);

        // If the order was saved successfully, redirect to a success page
        if (isOrderSaved) {
            // Optionally: Set attributes to display on the success page
            request.setAttribute("order", order);
            request.setAttribute("message", "Your order has been placed successfully!");

            // Forward to a success page (e.g., order-success.jsp)
            RequestDispatcher dispatcher = request.getRequestDispatcher("/order-success.jsp");
            dispatcher.forward(request, response);
        } else {
            // If the order failed to save, show an error message
            request.setAttribute("errorMessage", "There was an issue placing your order. Please try again.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/checkout.jsp");
            dispatcher.forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Redirect to checkout page if the request is GET (initial load)
        RequestDispatcher dispatcher = request.getRequestDispatcher("/checkout.jsp");
        dispatcher.forward(request, response);
    }
}

package com.chillspace.catalog;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import java.io.IOException;

@WebServlet("/category")
public class CategoryServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String category = request.getParameter("category");

        if (category == null || category.trim().isEmpty()) {
            request.setAttribute("error", "Category name can't be empty");
            request.getRequestDispatcher("/admin/categories.jsp").forward(request, response);
            return;
        }

        switch (action) {
            case "add":
                // TODO: Add category logic
                break;
            case "edit":
                // TODO: Edit category logic
                break;
            case "delete":
                // TODO: Delete category logic
                break;
        }

        response.sendRedirect("admin/categories.jsp");
    }
}

package com.chillspace.catalog;

import com.chillspace.util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String idStr = request.getParameter("id");
        String name = request.getParameter("name");
        String priceStr = request.getParameter("price");

        if ((action.equals("add") || action.equals("edit")) &&
                (name == null || name.trim().isEmpty() || priceStr == null || !priceStr.matches("\\d+(\\.\\d{1,2})?"))) {
            request.setAttribute("error", "Invalid name or price");
            request.getRequestDispatcher("/admin/products.jsp").forward(request, response);
            return;
        }

        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement stmt;

            switch (action) {
                case "add":
                    stmt = conn.prepareStatement("INSERT INTO products (name, price) VALUES (?, ?)");
                    stmt.setString(1, name);
                    stmt.setDouble(2, Double.parseDouble(priceStr));
                    stmt.executeUpdate();
                    break;

                case "edit":
                    stmt = conn.prepareStatement("UPDATE products SET name = ?, price = ? WHERE id = ?");
                    stmt.setString(1, name);
                    stmt.setDouble(2, Double.parseDouble(priceStr));
                    stmt.setInt(3, Integer.parseInt(idStr));
                    stmt.executeUpdate();
                    break;

                case "delete":
                    stmt = conn.prepareStatement("DELETE FROM products WHERE id = ?");
                    stmt.setInt(1, Integer.parseInt(idStr));
                    stmt.executeUpdate();
                    break;
            }

        } catch (SQLException e) {
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("/admin/products.jsp").forward(request, response);
            return;
        }

        response.sendRedirect("admin/products.jsp");
    }
}

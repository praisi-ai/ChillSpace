package com.chillspace.servlet;

import com.chillspace.dao.OrderDAO;
import com.chillspace.model.Order;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class OrderServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = Integer.parseInt(request.getParameter("user_id"));
        double totalAmount = Double.parseDouble(request.getParameter("total_amount"));
        String status = request.getParameter("status");
        String paymentStatus = request.getParameter("payment_status");

        Order order = new Order();
        order.setUserId(userId);
        order.setTotalAmount(totalAmount);
        order.setStatus(status);
        order.setPaymentStatus(paymentStatus);

        OrderDAO orderDAO = new OrderDAO();
        orderDAO.createOrder(order);

        response.sendRedirect("orderConfirmation.jsp");
    }
}

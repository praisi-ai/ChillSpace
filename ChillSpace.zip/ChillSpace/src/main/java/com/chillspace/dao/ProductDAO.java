package com.chillspace.dao;

import com.chillspace.model.Product;
import com.chillspace.util.DBUtil;
import java.sql.*;
import java.util.*;

public class ProductDAO {

    // Method to get a list of all products with pagination
    public List<Product> getAllProducts(int limit, int offset) {
        List<Product> productList = new ArrayList<>();
        String query = "SELECT * FROM Product LIMIT ? OFFSET ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, limit);
            pstmt.setInt(2, offset);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Product product = new Product();
                    product.setProductId(rs.getInt("product_id"));
                    product.setName(rs.getString("name"));
                    product.setDescription(rs.getString("description"));
                    product.setPrice(rs.getBigDecimal("price"));
                    product.setStockQuantity(rs.getInt("stock_quantity"));
                    product.setCategoryId(rs.getInt("category_id"));
                    product.setImageUrl(rs.getString("image_url"));
                    product.setProductDetails(rs.getString("product_details"));
                    productList.add(product);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return productList;
    }

    // Method to get products by category with pagination
    public List<Product> getProductsByCategory(int categoryId, int limit, int offset) {
        List<Product> productList = new ArrayList<>();
        String query = "SELECT * FROM Product WHERE category_id = ? LIMIT ? OFFSET ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, categoryId);
            pstmt.setInt(2, limit);
            pstmt.setInt(3, offset);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Product product = new Product();
                    product.setProductId(rs.getInt("product_id"));
                    product.setName(rs.getString("name"));
                    product.setDescription(rs.getString("description"));
                    product.setPrice(rs.getBigDecimal("price"));
                    product.setStockQuantity(rs.getInt("stock_quantity"));
                    product.setCategoryId(rs.getInt("category_id"));
                    product.setImageUrl(rs.getString("image_url"));
                    product.setProductDetails(rs.getString("product_details"));
                    productList.add(product);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return productList;
    }

    // Method to get the total count of products (for pagination)
    public int getProductCount() {
        int count = 0;
        String query = "SELECT COUNT(*) FROM Product";

        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                count = rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return count;
    }

    // Method to get the total count of products by category (for pagination)
    public int getProductCountByCategory(int categoryId) {
        int count = 0;
        String query = "SELECT COUNT(*) FROM Product WHERE category_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, categoryId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    count = rs.getInt(1);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return count;
    }

    // Method to add a new product to the database
    public void addProduct(Product product) {
        String query = "INSERT INTO Product (name, description, price, stock_quantity, category_id, image_url, product_details) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, product.getName());
            pstmt.setString(2, product.getDescription());
            pstmt.setBigDecimal(3, product.getPrice());
            pstmt.setInt(4, product.getStockQuantity());
            pstmt.setInt(5, product.getCategoryId());
            pstmt.setString(6, product.getImageUrl());
            pstmt.setString(7, product.getProductDetails());

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to get product by its ID
    public Product getProductById(int productId) {
        Product product = null;
        String query = "SELECT * FROM Product WHERE product_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, productId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    product = new Product();
                    product.setProductId(rs.getInt("product_id"));
                    product.setName(rs.getString("name"));
                    product.setDescription(rs.getString("description"));
                    product.setPrice(rs.getBigDecimal("price"));
                    product.setStockQuantity(rs.getInt("stock_quantity"));
                    product.setCategoryId(rs.getInt("category_id"));
                    product.setImageUrl(rs.getString("image_url"));
                    product.setProductDetails(rs.getString("product_details"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return product;
    }
    
    // Method to get the category name by category ID
    public String getCategoryNameById(int categoryId) {
        String categoryName = null;
        String query = "SELECT category_name FROM Category WHERE category_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, categoryId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    categoryName = rs.getString("category_name");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return categoryName;
    }
}

package com.chillspace.servlet;

import com.chillspace.dao.ProductDAO;
import com.chillspace.model.Product;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class ProductListServlet extends HttpServlet {

    private static final int PRODUCTS_PER_PAGE = 10;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the 'categoryFilter' parameter and page number from the request
        String categoryFilter = request.getParameter("categoryFilter");
        int pageNumber = 1;
        if (request.getParameter("page") != null) {
            pageNumber = Integer.parseInt(request.getParameter("page"));
        }

        // Calculate the offset based on the current page number
        int offset = (pageNumber - 1) * PRODUCTS_PER_PAGE;

        // Create ProductDAO instance
        ProductDAO productDAO = new ProductDAO();

        List<Product> productList;
        int totalProducts;

        if (categoryFilter != null && !categoryFilter.isEmpty()) {
            int categoryId = Integer.parseInt(categoryFilter);
            productList = productDAO.getProductsByCategory(categoryId, PRODUCTS_PER_PAGE, offset);
            totalProducts = productDAO.getProductCountByCategory(categoryId);
        } else {
            productList = productDAO.getAllProducts(PRODUCTS_PER_PAGE, offset);
            totalProducts = productDAO.getProductCount();
        }

        // Fetch category names for each product
        for (Product product : productList) {
            String categoryName = productDAO.getCategoryNameById(product.getCategoryId());
            product.setCategory(categoryName);  // Set the category name in the product object
        }

        // Calculate total number of pages
        int totalPages = (int) Math.ceil((double) totalProducts / PRODUCTS_PER_PAGE);

        // Set attributes for pagination and product list
        request.setAttribute("productList", productList);
        request.setAttribute("totalPages", totalPages);
        request.setAttribute("currentPage", pageNumber);
        request.setAttribute("categoryFilter", categoryFilter);

        // Forward the request to the product_list.jsp page
        RequestDispatcher dispatcher = request.getRequestDispatcher("/product_list.jsp");
        dispatcher.forward(request, response);
    }
}

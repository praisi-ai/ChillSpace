package com.chillspace.dao;

import com.chillspace.model.ContactMessage;
import java.util.ArrayList;
import java.util.List;

public class ContactDAO {
    private List<ContactMessage> contactMessages = new ArrayList<>();

    public boolean saveMessage(ContactMessage contactMessage) {
        // Simulating saving the message (e.g., saving it in the database)
        contactMessages.add(contactMessage);
        return true;
    }
}

package com.chillspace.model;

import java.util.HashMap;
import java.util.Map;

public class ShoppingCart {
    private Map<Integer, CartItem> items; // Product ID as key, CartItem as value

    public ShoppingCart() {
        this.items = new HashMap<>();
    }

    // Add product to the cart or update quantity
    public void addProduct(Product product, int quantity) {
        if (items.containsKey(product.getId())) {
            CartItem existingItem = items.get(product.getId());
            existingItem.setQuantity(existingItem.getQuantity() + quantity);
        } else {
            items.put(product.getId(), new CartItem(product, quantity));
        }
    }

    // Remove product from the cart
    public void removeProduct(int productId) {
        items.remove(productId);
    }

    // Get the total price of all products in the cart
    public double getTotal() {
        double total = 0;
        for (CartItem item : items.values()) {
            total += item.getProduct().getPrice() * item.getQuantity();
        }
        return total;
    }

    // Get all cart items
    public Map<Integer, CartItem> getItems() {
        return items;
    }

    // Cart item (product and its quantity)
    public static class CartItem {
        private Product product;
        private int quantity;

        public CartItem(Product product, int quantity) {
            this.product = product;
            this.quantity = quantity;
        }

        public Product getProduct() {
            return product;
        }

        public void setProduct(Product product) {
            this.product = product;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        // Calculate total price for this item
        public double getTotalPrice() {
            return product.getPrice() * quantity;
        }
    }
}

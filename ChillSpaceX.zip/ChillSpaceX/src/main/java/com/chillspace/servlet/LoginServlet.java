package com.chillspace.servlet;

import com.chillspace.dao.UserDAO;
import com.chillspace.model.User;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // If GET request, show the login page (display the form)
        RequestDispatcher dispatcher = request.getRequestDispatcher("/login.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the login credentials
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Call the loginUser method in UserDAO
        UserDAO userDAO = new UserDAO();
        User user = userDAO.loginUser(email, password);

        if (user != null) {
            // Successful login, create session and redirect to home page or dashboard
            HttpSession session = request.getSession();
            session.setAttribute("user", user);  // Store user object in session
            response.sendRedirect("home.jsp");  // Redirect to homepage/dashboard
        } else {
            // Login failed, show error message
            request.setAttribute("errorMessage", "Invalid email or password. Please try again.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/login.jsp");
            dispatcher.forward(request, response);
        }
    }
}

package com.chillspace.dao;

import com.chillspace.model.Order;
import com.chillspace.util.DBUtil;

import java.sql.*;
import java.math.BigDecimal;

public class OrderDAO {

    // Create a new order
    public void createOrder(Order order) {
        String query = "INSERT INTO Orders (total_amount, status, payment_status) VALUES (?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setBigDecimal(1, order.getTotalAmount());
            pstmt.setString(2, order.getStatus());
            pstmt.setString(3, order.getPaymentStatus());

            pstmt.executeUpdate();

            // Retrieve the generated order ID
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                order.setOrderId(rs.getInt(1));  // Set the generated order ID
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Get an order by ID
    public Order getOrderById(int orderId) {
        Order order = null;
        String query = "SELECT * FROM Orders WHERE order_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, orderId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                order = new Order();
                order.setOrderId(rs.getInt("order_id"));
                order.setTotalAmount(rs.getBigDecimal("total_amount"));
                order.setStatus(rs.getString("status"));
                order.setPaymentStatus(rs.getString("payment_status"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return order;
    }

    // Update the status of an order
    public void updateOrderStatus(int orderId, String newStatus) {
        String query = "UPDATE Orders SET status = ? WHERE order_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, newStatus);
            pstmt.setInt(2, orderId);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update the payment status of an order
    public void updatePaymentStatus(int orderId, String newPaymentStatus) {
        String query = "UPDATE Orders SET payment_status = ? WHERE order_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, newPaymentStatus);
            pstmt.setInt(2, orderId);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete an order by ID
    public void deleteOrder(int orderId) {
        String query = "DELETE FROM Orders WHERE order_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, orderId);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

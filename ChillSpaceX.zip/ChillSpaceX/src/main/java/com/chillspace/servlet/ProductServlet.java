package com.chillspace.servlet;

import com.chillspace.dao.ProductDAO;
import com.chillspace.model.Product;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

public class ProductServlet extends HttpServlet {

    // Method to handle GET requests
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the category parameter (if available) to filter products
        String category = request.getParameter("category");

        // Create a ProductDAO instance to fetch products
        ProductDAO productDAO = new ProductDAO();
        List<Product> products;

        if (category != null && !category.isEmpty()) {
            // If a category is provided, get products by category
            products = productDAO.getProductsByCategory(category);
        } else {
            // Otherwise, get all products
            products = productDAO.getAllProducts();
        }

        // Set the products as a request attribute to be used in the JSP
        request.setAttribute("products", products);

        // Forward the request to the shop.jsp for rendering
        RequestDispatcher dispatcher = request.getRequestDispatcher("/shop.jsp");
        dispatcher.forward(request, response);
    }

    // Optional: Handle POST requests (usually used for form submissions)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}

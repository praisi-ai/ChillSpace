// Class produk
class Product {
    constructor(name, category, price, image) {
      this.name = name;
      this.category = category;
      this.price = price;
      this.image = image;
    }
  
    render() {
      return `
        <div class="product">
          <img src="${this.image}" alt="${this.name}">
          <h3>${this.name}</h3>
          <p>Harga: Rp ${this.price}</p>
        </div>
      `;
    }
  }
  
  // Data produk
  const products = [
    new Product("Produk A", "elektronik", 30000, "https://via.placeholder.com/150"),
    new Product("Produk B", "peralatan", 20000, "https://via.placeholder.com/150"),
  ];
  
  // DOM elements
  const productList = document.getElementById("productList");
  const filterCategory = document.getElementById("filterCategory");
  const sortPrice = document.getElementById("sortPrice");
  
  // Tampilkan produk
  function displayProducts(list) {
    productList.innerHTML = list.map(p => p.render()).join('');
  }
  
  // Filter & Sort
  function updateProductList() {
    let filtered = [...products];
  
    if (filterCategory.value !== "all") {
      filtered = filtered.filter(p => p.category === filterCategory.value);
    }
  
    if (sortPrice.value === "asc") {
      filtered.sort((a, b) => a.price - b.price);
    } else {
      filtered.sort((a, b) => b.price - a.price);
    }
  
    displayProducts(filtered);
  }
  
  // Event listeners
  filterCategory.addEventListener("change", updateProductList);
  sortPrice.addEventListener("change", updateProductList);
  
  // Load awal
  updateProductList();
  
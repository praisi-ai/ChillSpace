package com.chillspace.servlet;

import com.chillspace.dao.ProductDAO;
import com.chillspace.model.Product;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class HomeServlet extends HttpServlet {

    private static final int PRODUCTS_PER_PAGE = 5; // Set the number of products to show per page

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get page number from the request
        int pageNumber = 1;
        if (request.getParameter("page") != null) {
            pageNumber = Integer.parseInt(request.getParameter("page"));
        }

        // Calculate offset
        int offset = (pageNumber - 1) * PRODUCTS_PER_PAGE;

        // Fetch products (can be limited or filtered if needed)
        ProductDAO productDAO = new ProductDAO();
        List<Product> featuredProductList = productDAO.getAllProducts(PRODUCTS_PER_PAGE, offset);  // Pass limit and offset

        // Set the featured product list as a request attribute to be used in the JSP
        request.setAttribute("featuredProductList", featuredProductList);

        // Forward the request to the index.jsp page
        RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
        dispatcher.forward(request, response);
    }
}

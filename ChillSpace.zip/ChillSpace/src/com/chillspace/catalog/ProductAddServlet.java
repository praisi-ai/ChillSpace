package com.chillspace.catalog;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class ProductAddServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        String name = request.getParameter("name");
        String priceStr = request.getParameter("price");

        // Basic validation
        if (name == null || name.trim().isEmpty() || priceStr == null || priceStr.trim().isEmpty()) {
            response.sendRedirect("error.jsp");
            return;
        }

        try {
            double price = Double.parseDouble(priceStr);

            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to  MySQL database
            try (
                    Connection conn = DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/chillspace", "root", "yourpassword");
                    PreparedStatement ps = conn.prepareStatement(
                            "INSERT INTO product (name, price) VALUES (?, ?)")
            ) {
                ps.setString(1, name);
                ps.setDouble(2, price);
                ps.executeUpdate();

                // Redirect to success page
                response.sendRedirect("success.jsp");
            }

        } catch (NumberFormatException e) {
            // Invalid price input
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        } catch (Exception e) {
            // Database or other error
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}

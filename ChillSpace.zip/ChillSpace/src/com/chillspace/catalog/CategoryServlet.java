package com.chillspace.catalog;

import com.chillspace.util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class CategoryServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String idStr = request.getParameter("id");
        String name = request.getParameter("name");

        if ((action.equals("add") || action.equals("edit")) &&
                (name == null || name.trim().isEmpty())) {
            request.setAttribute("error", "Category name can't be empty");
            request.getRequestDispatcher("/admin/categories.jsp").forward(request, response);
            return;
        }

        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement stmt;

            switch (action) {
                case "add":
                    stmt = conn.prepareStatement("INSERT INTO categories (name) VALUES (?)");
                    stmt.setString(1, name);
                    stmt.executeUpdate();
                    break;

                case "edit":
                    stmt = conn.prepareStatement("UPDATE categories SET name = ? WHERE id = ?");
                    stmt.setString(1, name);
                    stmt.setInt(2, Integer.parseInt(idStr));
                    stmt.executeUpdate();
                    break;

                case "delete":
                    stmt = conn.prepareStatement("DELETE FROM categories WHERE id = ?");
                    stmt.setInt(1, Integer.parseInt(idStr));
                    stmt.executeUpdate();
                    break;
            }

        } catch (SQLException e) {
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("/admin/categories.jsp").forward(request, response);
            return;
        }

        response.sendRedirect("admin/categories.jsp");
    }
}

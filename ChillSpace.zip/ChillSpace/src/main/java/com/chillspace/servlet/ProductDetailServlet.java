package com.chillspace.servlet;

import com.chillspace.dao.ProductDAO;
import com.chillspace.model.Product;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class ProductDetailServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productId = request.getParameter("id");

        // Fetch the product details from the database using ProductDAO
        ProductDAO productDAO = new ProductDAO();
        Product product = productDAO.getProductById(Integer.parseInt(productId));

        if (product != null) {
            // Set the product details as a request attribute
            request.setAttribute("product", product);
            // Forward the request to the product_detail.jsp page
            RequestDispatcher dispatcher = request.getRequestDispatcher("/product_detail.jsp");
            dispatcher.forward(request, response);
        } else {
            // If no product is found, redirect to the product list or error page
            response.sendRedirect("productList");
        }
    }
}

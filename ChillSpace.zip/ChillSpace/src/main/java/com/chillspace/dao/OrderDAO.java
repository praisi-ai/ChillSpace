
package com.chillspace.dao;

import com.chillspace.model.Order;
import com.chillspace.util.DBUtil;
import java.sql.*;
import java.util.*;

public class OrderDAO {
    public void createOrder(Order order) {
        String query = "INSERT INTO `Order` (user_id, total_amount, status, payment_status) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, order.getUserId());
            pstmt.setBigDecimal(2, order.getTotalAmount());
            pstmt.setString(3, order.getStatus());
            pstmt.setString(4, order.getPaymentStatus());

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to get a single order by order ID
    public Order getOrderById(int orderId) {
        Order order = null;
        String query = "SELECT * FROM `Order` WHERE order_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, orderId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                order = new Order();
                order.setOrderId(rs.getInt("order_id"));
                order.setUserId(rs.getInt("user_id"));
                order.setTotalAmount(rs.getBigDecimal("total_amount"));
                order.setStatus(rs.getString("status"));
                order.setPaymentStatus(rs.getString("payment_status"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return order;
    }
}

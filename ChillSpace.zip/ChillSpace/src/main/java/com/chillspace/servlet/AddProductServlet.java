package com.chillspace.servlet;

import com.chillspace.dao.ProductDAO;
import com.chillspace.model.Product;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;


public class AddProductServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Display the "Add Product" form (use JSP to create the form)
        RequestDispatcher dispatcher = request.getRequestDispatcher("/addProduct.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String description = request.getParameter("description");

        // Convert price to BigDecimal from double
        double price = Double.parseDouble(request.getParameter("price"));
        BigDecimal priceBigDecimal = BigDecimal.valueOf(price); // Convert double to BigDecimal

        int stockQuantity = Integer.parseInt(request.getParameter("stock_quantity"));
        int categoryId = Integer.parseInt(request.getParameter("category_id"));
        String imageUrl = request.getParameter("image_url");
        String productDetails = request.getParameter("product_details");

        Product product = new Product();
        product.setName(name);
        product.setDescription(description);
        product.setPrice(priceBigDecimal); // Use BigDecimal here
        product.setStockQuantity(stockQuantity);
        product.setCategoryId(categoryId);
        product.setImageUrl(imageUrl);
        product.setProductDetails(productDetails);

        ProductDAO productDAO = new ProductDAO();
        productDAO.addProduct(product);

        response.sendRedirect("productList");
    }

}

package com.chillspace.dao;

import com.chillspace.model.Order;
import java.sql.*;
import java.math.BigDecimal;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CheckoutDAO {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/chillspace";  // Update with your DB URL
    private static final String DB_USERNAME = "root";  // Update with your DB username
    private static final String DB_PASSWORD = "";  // Update with your DB password

    private static final Logger LOGGER = Logger.getLogger(CheckoutDAO.class.getName());

    // Method to save an order to the database
    public boolean saveOrder(Order order) {
        Connection connection = null;
        PreparedStatement stmt = null;
        boolean success = false;

        try {
            // Establishing the database connection
            connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);

            // SQL query to insert order details into the orders table
            String sql = "INSERT INTO orders (user_id, total_amount, status, payment_status) VALUES (?, ?, ?, ?)";
            stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            // Set the parameters for the query
            stmt.setInt(1, order.getUserId());  // Set user ID
            stmt.setBigDecimal(2, order.getTotalAmount());  // Set total amount
            stmt.setString(3, order.getStatus());  // Set order status (e.g., Pending)
            stmt.setString(4, order.getPaymentStatus());  // Set payment status (e.g., Unpaid)

            // Execute the update and check if any rows were affected
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                // Retrieve the generated order ID
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        order.setOrderId(generatedKeys.getInt(1));  // Set the generated order ID to the order object
                    }
                }
                success = true;  // Order successfully saved
            } else {
                LOGGER.log(Level.WARNING, "No rows affected while saving the order.");
            }

        } catch (SQLException e) {
            // Log SQL exception with a meaningful message
            LOGGER.log(Level.SEVERE, "Error while saving the order to the database", e);
        } finally {
            // Ensure resources are closed properly to avoid connection leaks
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                LOGGER.log(Level.SEVERE, "Error closing database resources", e);
            }
        }

        return success;
    }
}

package com.chillspace.servlet;

import com.chillspace.dao.UserDAO;
import com.chillspace.model.User;
import org.mindrot.jbcrypt.BCrypt;  // Import BCrypt for hashing

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class RegisterServlet extends HttpServlet {

    // Handle GET requests to show the registration form
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward to the register.jsp page
        RequestDispatcher dispatcher = request.getRequestDispatcher("/register.jsp");
        dispatcher.forward(request, response);
    }

    // Handle POST requests to process the registration data
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve registration form parameters
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Hash the password before saving it to the User object
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

        // Create a new User object and set the fields
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPasswordHash(hashedPassword);  // Set the hashed password

        // Call UserDAO to register the user
        UserDAO userDAO = new UserDAO();
        boolean isUserRegistered = userDAO.registerUser(user, password);

        if (isUserRegistered) {
            // Registration successful, redirect to login page or home page
            response.sendRedirect("login");  // Redirect to login page for user to log in
        } else {
            // Registration failed, show error message
            request.setAttribute("errorMessage", "Registration failed. Please try again.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/register.jsp");
            dispatcher.forward(request, response);
        }
    }
}

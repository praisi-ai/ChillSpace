package com.chillspace.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import com.chillspace.dao.ContactDAO;
import com.chillspace.model.ContactMessage;

public class ContactServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String message = request.getParameter("message");

        ContactMessage contactMessage = new ContactMessage(name, email, message);
        ContactDAO contactDAO = new ContactDAO();
        
        boolean isMessageSaved = contactDAO.saveMessage(contactMessage);
        
        if (isMessageSaved) {
            request.setAttribute("message", "Your message has been sent successfully.");
        } else {
            request.setAttribute("message", "There was an error sending your message.");
        }
        
        // Forwarding to the contact.jsp with the response
        request.getRequestDispatcher("/contact.jsp").forward(request, response);
    }
}
